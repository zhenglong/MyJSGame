/*
 * PlayScene.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";

var PlayScene = cc.Scene.extend({
	space: null,
	shapesToRemove: [],
	gameLayer: null,
	initPhysics: function() {
		this.space = new cp.Space();
		this.space.gravity = cp.v(0, -350);

		var wallBottom = new cp.SegmentShape(this.space.staticBody,
			cp.v(0, g_groundHeight),
			cp.v(4294967295, g_groundHeight),
			0);
		this.space.addStaticShape(wallBottom);

		this.space.addCollisionHandler(SpriteTag.runner, SpriteTag.coin,
			this.collisionCoinBegin.bind(this), null, null, null);
		this.space.addCollisionHandler(SpriteTag.runner, SpriteTag.rock,
			this.collisionRockBegin.bind(this), null, null, null);
	},
	collisionCoinBegin: function(arbiter, space) {
		var shapes = arbiter.getShapes();
		this.shapesToRemove.push(shapes[1]);
	},
	collisionRockBegin: function(arbiter, space) {
		cc.log('==game over');
	},
	update: function(dt) {
		this.space.step(dt);

		for (var i = 0; i < this.shapesToRemove.length; i++) {
			var shape = this.shapesToRemove[i];
			this.gameLayer.getChildByTag(TagOfLayer.background).removeObjectByShape(shape);
		}
		this.shapesToRemove = [];

		var animationLayer = this.gameLayer.getChildByTag(TagOfLayer.animation);
		var eyeX = animationLayer.getEyeX();
		this.gameLayer.setPosition(cc.p(-eyeX, 0));
	},
	onEnter: function() {
		this._super();
		this.initPhysics();
		this.gameLayer = new cc.Layer();

		this.gameLayer.addChild(new BackgroundLayer(this.space), 0, TagOfLayer.background);
		this.gameLayer.addChild(new AnimationLayer(this.space),0, TagOfLayer.animation);
		this.addChild(this.gameLayer);
		this.addChild(new StatusLayer(), 0, TagOfLayer.status);

		this.scheduleUpdate();
	}
 });
