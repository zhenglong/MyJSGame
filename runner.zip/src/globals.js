/*
 * globals.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";

var g_groundHeight = 57;
var g_runnerStartX = 80;

if (typeof TagOfLayer == 'undefined') {
	var TagOfLayer = {
		background: 0,
		animation: 1,
		status: 2
	};
}
if (typeof SpriteTag == 'undefined') {
	var SpriteTag = {
		runner: 0,
		coin: 1,
		rock: 2
	};
}
