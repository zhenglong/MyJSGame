/*
 * MyActionScene.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";
var ActionTypes = {
	kExplosion: 0,
	kFire: 1,
	kFireworks: 2,
	kFlower: 3,
	kGalaxy: 4,
	kMeteor: 5,
	kRain: 6,
	kSmoke: 7,
	kSnow: 8,
	kSpiral: 9,
	kSun: 10,
	all: 11
}
var MyActionLayer = cc.Layer.extend({
	flagTag: 0,
	pLable: null,
	ctor: function(flagTag) {
		this._super();
		this.flagTag = flagTag;

		var size = cc.winSize;

		this.pLabel = new cc.LabelTTF('aaaaaaa', 'Arial', 38);
		this.pLabel.setPosition(size.width / 2, size.height - 50);
		this.addChild(this.pLabel, 3);

		return true;
	},
	onEnter: function() {
		cc.log('entered');
	},
	onEnterTransitionDidFinish: function() {
		var size = cc.winSize;

		var system;
		switch(this.flagTag) {
			case ActionTypes.kExplosion:
				system = new cc.ParticleExplosion();
				this.pLabel.setString('Explosion');
				break;
			case ActionTypes.kFire:
				system = new cc.ParticleFire();
				this.pLabel.setString('Fire');
				break;
			case ActionTypes.kFireworks:
				system = new cc.ParticleFireworks();
				this.pLabel.setString('fireworks');
				break;
			case ActionTypes.kFlower:
				system = new cc.ParticleFlower();
				this.pLabel.setString('Flower');
				break;
			case ActionTypes.kGalaxy:
				system = new cc.ParticleGalaxy();
				this.pLabel.setString('Galaxy');
				break;
			case ActionTypes.kMeteor:
				system = new cc.ParticleMeteor();
				this.pLabel.setString('Meteor');
				break;
			case ActionTypes.kRain:
				system = new cc.ParticleRain();
				this.pLabel.setString('Rain');
				break;
			case ActionTypes.kSmoke:
				system = new cc.ParticleSmoke();
				this.pLabel.setString('Smoke');
				break;
			case ActionTypes.kSnow:
				system = new cc.ParticleSnow();
				this.pLabel.setString('Snow');
				break;
			case ActionTypes.kSpiral:
				system = new cc.ParticleSpiral();
				this.pLabel.setString('Spiral');
				break;
			case ActionTypes.kSun:
				system = new cc.ParticleSun();
				this.pLabel.setString('Sun');
				break;
			default:
				cc.log('unrecognized action type:' + this.flagTag);
				break;
		}
		system.setTexture(cc.textureCache.addImage(res.runner_png));
		system.setPosition(size.width / 2, size.height / 2);
		this.addChild(system);
	}
});

var MyActionScene = cc.Scene.extend({
	layer: null,
	ctor: function() {
		this._super();
		this.layer = new MyActionLayer(Math.floor(Math.random() * ActionTypes.all));
		this.addChild(this.layer);
	}
});
