/*
 * physicsLayer.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";

var DEBUG_NODE_SHOW = true;
var SPRITE_WIDTH = 48;
var SPRITE_HEIGHT = 48;

var PhysicsScene = cc.Scene.extend({
	layer: null,
	ctor: function() {
		this._super();
		this.layer = new PhysicsLayer();
		this.addChild(this.layer);
	}
});

var PhysicsLayer = cc.Layer.extend({
	space: null,
	debugNode: null,
	ctor: function() {
		this._super();
		this.initSpace();
		this.scheduleUpdate();
	},
	initSpace: function() {
		this.space = new cp.Space();
		//this.setupDebugNode();
		this.space.iterations = 60;
		this.space.gravity = cp.v(0, -500);
		this.space.sleepTimeThreshold = .5;
		this.space.collisionSlop = .5;

		this.addWalls();
	},
	setupDebugNode: function() {
		this.debugNode = new cc.PhysicsDebugNode(this.space);
		this.debugNode.visible = DEBUG_NODE_SHOW;
		this.addChild(this.debugNode);
	},
	addWalls: function() {
		var winSize = cc.director.getWinSize();
		var walls = [new cp.SegmentShape(this.space.staticBody, cp.v(0, 0), cp.v(winSize.width, 0), 0),
			new cp.SegmentShape(this.space.staticBody, cp.v(0, winSize.height), cp.v(winSize.width, winSize.height), 0),
			new cp.SegmentShape(this.space.staticBody, cp.v(0, 0), cp.v(0, winSize.height), 0),
			new cp.SegmentShape(this.space.staticBody, cp.v(winSize.width, 0), cp.v(winSize.width, winSize.height), 0)];
		for (var i = 0; i < walls.length; i++) {
			var w = walls[i];
			w.setElasticity(1);
			w.setFriction(1);
			this.space.addStaticShape(w);
		};
	},
	onEnter: function() {
		this._super();
		cc.eventManager.addListener({
			event: cc.EventListener.TOUCH_ONE_BY_ONE,
			onTouchBegan: this.onTouchBegan
		}, this);
	},
	onTouchBegan: function(touch, event) {
		var target = event.getCurrentTarget();
		var location = touch.getLocation();
		var i = 0;
		function loop() {
			setTimeout(function() {
				target.addNewSpriteAtPosition(location);
				i++;
				if (i == 10) return;
				loop();
			}, 100); 
		}
		loop();
		return false;
	},
	onExit: function() {
		this._super();
		cc.eventManager.removeListener(cc.EventListener.TOUCH_ONE_BY_ONE);
	},
	sprites: [],
	addNewSpriteAtPosition: function(pos) {
		var body = new cp.Body(1, cp.momentForBox(1, SPRITE_WIDTH, SPRITE_HEIGHT));
		body.setVel(new cp.Vect((Math.random() > .5 ? -1 : 1)*500*Math.random(), 
					100*Math.random()));
		body.setAngle(Math.PI * Math.random());
		body.setPos(pos);
		this.space.addBody(body);

		var shape = new cp.CircleShape(body, SPRITE_WIDTH/2 - 3, new cp.Vect(0, 0));
		//var shape = new cp.BoxShape(body, SPRITE_WIDTH, SPRITE_HEIGHT);
		shape.setElasticity(.5);
		shape.setFriction(.5);
		this.space.addShape(shape);

		var sprite = cc.PhysicsSprite.create(res.coin_png);
		sprite.setScale(SPRITE_WIDTH / sprite.getContentSize().width);
		sprite.setBody(body);
		sprite.setPosition(cc.p(pos.x, pos.y));
		this.sprites.push(sprite);
		this.addChild(sprite, 0, this.sprites.length);
	},
	update: function(dt) {
		var timeStep = .03;
		this.space.step(timeStep);
	}
});
