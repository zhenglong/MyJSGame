/*
 * StatusLayer.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";

var StatusLayer = cc.Layer.extend({
	labelCoin: null,
	labelMeter: null,
	coins: 0,

	ctor: function() {
		this._super();
		this.init();
	},
	init: function() {
		this._super();

		var winsize = cc.director.getWinSize();
		this.labelCoin = new cc.LabelTTF('Coins:0', 'Helvetica', 20);
		this.labelCoin.setColor(cc.color(0,0,0));
		var y = winsize.height - 100, x = 130;
		this.labelCoin.setPosition(cc.p(x, y));
		this.addChild(this.labelCoin);

		this.labelMeter = new cc.LabelTTF('0M', 'Helvetica', 20);
		this.labelMeter.setPosition(cc.p(winsize.width - x, y));
		this.addChild(this.labelMeter);
	}
});
