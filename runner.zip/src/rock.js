/*
 * rock.js
 * Copyright (C) 2015 tristan <tristan@tristan-VirtualBox>
 *
 * Distributed under terms of the MIT license.
 */

"use strict";

var Rock = cc.Class.extend({
	space: null,
	sprite: null,
	shape: null,
	_map: 0,
	get map() {
		return this._map;
	},
	set map(newMap) {
		this._map = newMap;
	},

	ctor: function(spriteSheet, space, posX) {
		this.space = space;
		this.sprite = new cc.PhysicsSprite('#rock.png');
		var body = new cp.StaticBody();
		var contentSize = this.sprite.getContentSize();
		body.setPos(cc.p(posX, contentSize.height/2 + g_groundHeight));
		this.sprite.setBody(body);

		this.shape = new cp.BoxShape(body,
			contentSize.width, contentSize.height);
		this.shape.setCollisionType(SpriteTag.rock);

		this.space.addStaticShape(this.shape);
		spriteSheet.addChild(this.sprite);
	},

	removeFromParent: function() {
		this.space.removeStaticShape(this.shape);
		this.shape = null;
		this.sprite.removeFromParent();
		this.sprite = null;
	},
	getShape: function() {
		return this.shape;
	}
});
